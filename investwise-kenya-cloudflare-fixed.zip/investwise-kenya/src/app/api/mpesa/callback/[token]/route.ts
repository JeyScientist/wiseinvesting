import { NextResponse } from 'next/server';
import { parseCallback, secretsMatch } from '@/lib/payments';
import { adminClient } from '@/lib/supabase/admin';
import { serverEnv } from '@/lib/env';

// Safaricom does not sign callbacks, so the URL carries a secret and settlement is atomic + idempotent in SQL.
export async function POST(req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  if (!secretsMatch(token, serverEnv().MPESA_CALLBACK_SECRET)) return new NextResponse('Not found', { status: 404 });
  const body = await req.json().catch(() => null);
  const cb = parseCallback(body);
  if (!cb) return NextResponse.json({ ResultCode: 1, ResultDesc: 'Invalid payload' }, { status: 400 });

  const { data, error } = await adminClient().rpc('settle_payment', {
    p_checkout_request_id: cb.checkoutRequestId, p_result_code: cb.resultCode, p_result_desc: cb.resultDesc,
    p_receipt: cb.receipt, p_amount: cb.amount, p_raw: body,
  });
  if (error) return NextResponse.json({ ResultCode: 1, ResultDesc: 'Retry later' }, { status: 500 });
  console.info('mpesa callback', { checkout: cb.checkoutRequestId, outcome: data });
  return NextResponse.json({ ResultCode: 0, ResultDesc: 'Accepted' });
}
