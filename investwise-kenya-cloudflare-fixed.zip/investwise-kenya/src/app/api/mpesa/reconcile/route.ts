import { NextResponse } from 'next/server';
import { adminClient } from '@/lib/supabase/admin';
import { stkQuery } from '@/lib/daraja';
import { secretsMatch } from '@/lib/payments';
import { serverEnv } from '@/lib/env';

/** Run on a schedule (Vercel Cron / external). Queries Safaricom for payments still pending after 2 minutes.
 *  A Daraja query result carries no receipt, so a success here is NOT settled automatically: it is flagged
 *  for admin review until the callback (with receipt) arrives. Failures and cancellations are settled. */
export async function GET(req: Request) {
  const auth = req.headers.get('authorization') ?? '';
  if (!secretsMatch(auth, `Bearer ${serverEnv().CRON_SECRET}`)) return new NextResponse('Forbidden', { status: 403 });
  const db = adminClient();
  const cutoff = new Date(Date.now() - 2 * 60_000).toISOString();
  const { data: pending } = await db.from('payments').select('id,checkout_request_id,amount_kes')
    .eq('status', 'pending').lt('created_at', cutoff).limit(50);
  let settled = 0, flagged = 0;
  for (const p of pending ?? []) {
    const q = await stkQuery(p.checkout_request_id!).catch(() => null);
    if (!q) continue;
    if (q.resultCode === 0) {
      await db.from('audit_logs').insert({ action: 'reconcile_success_needs_receipt', target: p.id, detail: q });
      flagged++;
    } else {
      await db.rpc('settle_payment', { p_checkout_request_id: p.checkout_request_id, p_result_code: q.resultCode, p_result_desc: q.resultDesc, p_receipt: null, p_amount: null, p_raw: q });
      settled++;
    }
  }
  return NextResponse.json({ checked: pending?.length ?? 0, settled, flagged });
}
