import Link from 'next/link';
import { projectGrowth } from '@/lib/calculators';
import { formatKES } from '@/lib/money';

// Illustrative arithmetic only, computed from stated assumptions, not a forecast or a product return.
const demo = projectGrowth({ principal: 0, monthlyContribution: 5000, annualRatePct: 8, years: 10, annualInflationPct: 0 }).at(-1)!;

export default function Home() {
  return (
    <div className="grid items-center gap-10 md:grid-cols-2">
      <section>
        <h1 className="text-4xl font-semibold leading-tight md:text-5xl">Understand your money before you invest it.</h1>
        <p className="mt-5 max-w-prose text-lg text-slate-300">Plain-language guides, honest calculators and affordable reports for people building savings in Kenya.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/tools" className="rounded bg-emerald px-5 py-3 font-medium text-navy-950 hover:bg-emerald-400">Try the calculators</Link>
          <Link href="/learn" className="rounded border border-gold px-5 py-3 text-gold hover:bg-navy-800">Start learning</Link>
        </div>
      </section>
      <section aria-labelledby="demo" className="rounded-lg border border-navy-700 bg-navy-900 p-6">
        <h2 id="demo" className="text-sm text-slate-400">Worked example</h2>
        <p className="mt-2 text-slate-300">Saving {formatKES(5000)} a month for 10 years at an assumed 8% a year grows to about</p>
        <p className="mt-1 text-3xl font-semibold text-emerald">{formatKES(Math.round(demo.balance))}</p>
        <p className="mt-1 text-sm text-slate-400">of which {formatKES(demo.contributed)} is your own money.</p>
        <p className="mt-4 text-xs text-slate-500">An assumption, not a promise. Real returns vary and can be negative.</p>
      </section>
    </div>
  );
}
