import { CompoundCalculator } from '@/components/CompoundCalculator';
export const metadata = { title: 'Compound interest calculator' };
export default function Page() {
  return (<div><h1 className="text-3xl font-semibold">Compound interest calculator</h1>
    <p className="mt-2 max-w-prose text-slate-300">Enter your own assumptions. Results are estimates, not guaranteed returns. Rates are nominal annual rates compounded monthly; contributions are added at each month end.</p>
    <CompoundCalculator /></div>);
}
