import 'server-only';
import { supabaseServer } from './supabase/server';
import { adminClient } from './supabase/admin';

export async function getUser() {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();   // validates the JWT with Supabase, unlike getSession()
  return data.user;
}
/** Role is read from the database on every call, never from client-supplied data. */
export async function isAdmin(userId: string): Promise<boolean> {
  const { data } = await adminClient().from('profiles').select('role').eq('id', userId).single();
  return data?.role === 'admin';
}
export async function requireAdmin() {
  const user = await getUser();
  if (!user || !(await isAdmin(user.id))) throw new Response('Forbidden', { status: 403 });
  return user;
}
