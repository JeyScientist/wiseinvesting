export interface GrowthInput {
  principal: number; monthlyContribution: number; annualRatePct: number;
  years: number; annualInflationPct: number; compoundsPerYear?: number;
}
export interface GrowthPoint { year: number; balance: number; contributed: number; realBalance: number }

/** Month-by-month projection. Contributions are made at month end. Estimate only, not a forecast. */
export function projectGrowth(i: GrowthInput): GrowthPoint[] {
  const m = i.compoundsPerYear ?? 12;
  if (![1, 2, 4, 12, 365].includes(m)) throw new RangeError('unsupported compounding frequency');
  if (i.years < 0 || i.years > 60) throw new RangeError('years must be 0-60');
  const r = i.annualRatePct / 100, infl = i.annualInflationPct / 100;
  const months = Math.round(i.years * 12);
  const monthlyRate = Math.pow(1 + r / m, m / 12) - 1;
  let bal = i.principal, contributed = i.principal;
  const out: GrowthPoint[] = [{ year: 0, balance: bal, contributed, realBalance: bal }];
  for (let k = 1; k <= months; k++) {
    bal = bal * (1 + monthlyRate) + i.monthlyContribution;
    contributed += i.monthlyContribution;
    if (k % 12 === 0) {
      const y = k / 12;
      out.push({ year: y, balance: bal, contributed, realBalance: bal / Math.pow(1 + infl, y) });
    }
  }
  return out;
}

/** Monthly saving needed to reach a target, given a starting amount and assumed annual return. */
export function monthlySavingsNeeded(target: number, current: number, annualRatePct: number, years: number, compoundsPerYear = 12): number {
  const n = Math.round(years * 12);
  if (n <= 0) throw new RangeError('years must be positive');
  // Same convention as projectGrowth: the annual rate is nominal, compounded `compoundsPerYear` times a year.
  const i = Math.pow(1 + annualRatePct / 100 / compoundsPerYear, compoundsPerYear / 12) - 1;
  const grownCurrent = current * Math.pow(1 + i, n);
  const gap = Math.max(0, target - grownCurrent);
  return i === 0 ? gap / n : (gap * i) / (Math.pow(1 + i, n) - 1);
}

export const realValue = (nominal: number, inflationPct: number, years: number) =>
  nominal / Math.pow(1 + inflationPct / 100, years);
