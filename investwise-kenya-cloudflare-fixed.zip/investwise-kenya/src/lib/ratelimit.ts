/** In-memory sliding window. Per-instance only: replace with Redis/Upstash for multi-instance production. */
const hits = new Map<string, number[]>();
export function rateLimit(key: string, limit: number, windowMs: number, now = Date.now()): boolean {
  const recent = (hits.get(key) ?? []).filter(t => now - t < windowMs);
  if (recent.length >= limit) { hits.set(key, recent); return false; }
  recent.push(now); hits.set(key, recent); return true;
}
export const _resetRateLimit = () => hits.clear();
