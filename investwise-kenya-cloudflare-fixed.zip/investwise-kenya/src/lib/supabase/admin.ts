import 'server-only';
import { createClient } from '@supabase/supabase-js';
import { serverEnv } from '../env';
/** Service-role client: bypasses RLS. Import only from server code (route handlers, server actions). */
export const adminClient = () => {
  const e = serverEnv();
  return createClient(e.NEXT_PUBLIC_SUPABASE_URL, e.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
};
