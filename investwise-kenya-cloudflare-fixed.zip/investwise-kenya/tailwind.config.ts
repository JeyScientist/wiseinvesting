import type { Config } from 'tailwindcss';
export default {
  content: ['./src/**/*.{ts,tsx}'],
  theme: { extend: { colors: {
    navy: { 950: '#07142b', 900: '#0b1d3a', 800: '#12294f', 700: '#1c3a6b' },
    emerald: { DEFAULT: '#10b981', deep: '#047857' },
    gold: '#c9a54b',
  }, fontFamily: { sans: ['var(--font-sans)', 'system-ui', 'sans-serif'], display: ['var(--font-display)', 'Georgia', 'serif'] } } },
} satisfies Config;
