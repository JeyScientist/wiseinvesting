import { describe, it, expect, beforeEach } from 'vitest';
import { parseCallback, secretsMatch, checkoutSchema } from '@/lib/payments';
import { normalizeKenyanPhone } from '@/lib/money';
import { rateLimit, _resetRateLimit } from '@/lib/ratelimit';

const ok = { Body: { stkCallback: { MerchantRequestID: 'm', CheckoutRequestID: 'ws_CO_1', ResultCode: 0, ResultDesc: 'ok',
  CallbackMetadata: { Item: [{ Name: 'Amount', Value: 150 }, { Name: 'MpesaReceiptNumber', Value: 'ABC123XYZ' }, { Name: 'PhoneNumber', Value: 254712345678 }] } } } };

describe('parseCallback', () => {
  it('extracts receipt and amount from a success payload', () => {
    expect(parseCallback(ok)).toMatchObject({ checkoutRequestId: 'ws_CO_1', resultCode: 0, receipt: 'ABC123XYZ', amount: 150 });
  });
  it('handles a cancelled payload with no metadata', () => {
    const r = parseCallback({ Body: { stkCallback: { MerchantRequestID: 'm', CheckoutRequestID: 'c', ResultCode: 1032, ResultDesc: 'cancelled' } } });
    expect(r).toMatchObject({ resultCode: 1032, receipt: null, amount: null });
  });
  it('rejects malformed payloads', () => {
    expect(parseCallback({})).toBeNull();
    expect(parseCallback(null)).toBeNull();
    expect(parseCallback({ Body: { stkCallback: { ResultCode: 'x' } } })).toBeNull();
  });
});

describe('secretsMatch', () => {
  it('matches only identical secrets', () => {
    expect(secretsMatch('abc', 'abc')).toBe(true);
    expect(secretsMatch('abc', 'abd')).toBe(false);
    expect(secretsMatch('abc', 'abcd')).toBe(false);
  });
});

describe('checkoutSchema', () => {
  it('ignores any client-supplied price', () => {
    const r = checkoutSchema.parse({ productId: '3f2b1c3e-8a1d-4c55-9a52-6d6a2d3b1f10', phone: '0712345678', price: 1 });
    expect('price' in r).toBe(false);
  });
  it('requires a uuid product id', () => {
    expect(checkoutSchema.safeParse({ productId: 'nope', phone: '0712345678' }).success).toBe(false);
  });
});

describe('normalizeKenyanPhone', () => {
  it.each([['0712345678', '254712345678'], ['+254712345678', '254712345678'], ['712345678', '254712345678'], ['0112345678', '254112345678']])('%s', (i, o) => {
    expect(normalizeKenyanPhone(i)).toBe(o);
  });
  it.each(['0212345678', '12345', 'abc', ''])('rejects %s', i => expect(normalizeKenyanPhone(i)).toBeNull());
});

describe('rateLimit', () => {
  beforeEach(_resetRateLimit);
  it('blocks after the limit and recovers after the window', () => {
    for (let i = 0; i < 3; i++) expect(rateLimit('k', 3, 1000, 0)).toBe(true);
    expect(rateLimit('k', 3, 1000, 10)).toBe(false);
    expect(rateLimit('k', 3, 1000, 2000)).toBe(true);
  });
});
